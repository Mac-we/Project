//
//  ContactdetailsViewController.swift
//  CampusToday
//
//  Created by 2 on 2021/1/10.
//  Copyright © 2021 iflytek. All rights reserved.
//

import UIKit

class ContactdetailsViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutviews()
        
}

    func layoutviews(){
        setBackItem()
        
        
        
        
        
        
        
    }

    func setBackItem() {
        // 1, 隐藏原来的返回按钮
        navigationItem.hidesBackButton = true
        // 2, 创建具备返回功能的按钮
        let backItem = UIBarButtonItem(title: "返回", style: .plain, target: self, action: #selector(back(sender:)))
        // 3, 将新建的按钮指定给返回按钮
        navigationItem.leftBarButtonItem = backItem
        
    }
    
    @objc func back(sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }




}
