
import UIKit


class RegistrationViewController: UIViewController {
    
    var HUD: MBProgressHUD?
    var BG = UIImageView()
    var accountText = UITextField()
    var passwordText = UITextField()
    var registerBtn = UIButton()
    
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        layoutView()
        loadSettings()

    }
   
  //MARK:布局----------------------------------
    
    func loadSettings(){
        //        let userDefaults = UserDefaults.standard
        //        let account = userDefaults.object(forKey: "account") as!String
        //        let pwd = userDefaults.object(forKey: "password") as!String
        //        accountText.text = account
        //        passwordText.text = pwd
        passwordText.isSecureTextEntry = true
        
        
    }
    
    
    func layoutView() {
        BG.image = UIImage(named: "今日校园")
        view.addSubview(BG)
        BG.snp.makeConstraints { (maker) in
            
            maker.top.equalToSuperview()
            
            maker.width.height.equalToSuperview()
        }
        
        
        
        // 设置圆角
        accountText.layer.cornerRadius = 5
        accountText.clipsToBounds = true
        // 设置占位符
        accountText.placeholder = "  请输入用户名"
        accountText.backgroundColor = .white
        view.addSubview(accountText)
        accountText.snp.makeConstraints { (maker) in
            maker.top.equalToSuperview().offset(SCREEN_HEIGHT*0.5)
            maker.centerX.equalToSuperview().offset(SCREEN_WIDTH*0.3)
            maker.left.equalToSuperview().offset(SCREEN_WIDTH*0.2)
            maker.right.equalToSuperview().inset(SCREEN_WIDTH*0.2)
            maker.height.equalTo(SCREEN_HEIGHT*0.05)
        }
        
        
        // 手机号
//        phonenumberText.layer.cornerRadius = 5
//        phonenumberText.clipsToBounds = true
//        phonenumberText.placeholder = "  请输入手机号"
//        phonenumberText.backgroundColor = .white
//        view.addSubview(phonenumberText)
//       phonenumberText.snp.makeConstraints { (maker) in
//            maker.top.equalTo(accountText.snp.bottom).offset(SCREEN_HEIGHT*0.03)
//            maker.centerX.left.right.height.equalTo(accountText)
//        }
        
        // 密码框
        passwordText.layer.cornerRadius = 5
        passwordText.clipsToBounds = true
        passwordText.placeholder = "  请输入密码"
        passwordText.backgroundColor = .white
        view.addSubview(passwordText)
        passwordText.snp.makeConstraints { (maker) in
            maker.top.equalTo( accountText.snp.bottom).offset(SCREEN_HEIGHT*0.03)
            maker.centerX.left.right.height.equalTo( accountText)
        }
        
        
        
        // 注册按钮
        registerBtn.setTitle("注册", for: .normal)
        registerBtn.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        registerBtn.backgroundColor = UIColor(red: 250/255.0, green: 190/255.0, blue: 187/255.0, alpha: 1.0)
        registerBtn.layer.cornerRadius = 10
        registerBtn.clipsToBounds = true
        registerBtn.addTarget(self, action: #selector(RegistrationSave(sender:)), for: .touchUpInside)
        view.addSubview(registerBtn)
        registerBtn.snp.makeConstraints { (maker) in
            maker.top.equalTo( passwordText.snp.bottom).offset(SCREEN_HEIGHT*0.03)
            maker.centerX.height.equalTo( passwordText)
            maker.width.equalTo(SCREEN_WIDTH*0.8)
        }
    }
    
    
    func showAlert(title:String,message:String){
        HUD = MBProgressHUD(view:view)
        view.addSubview(HUD!)
        HUD?.mode = MBProgressHUDModeText
        HUD?.labelText = title
        HUD?.detailsLabelText = message
        HUD?.show(animated: true, whileExecuting: {
            sleep(2)
        }, completionBlock:{
            self.HUD?.removeFromSuperview()
            self.HUD = nil
        })
    }
    
 //MARK:数据操作----------------------------------
    
    @objc func RegistrationSave(sender: UIButton){
   
        if  (accountText.text == nil) || (accountText.text == ""){
            
            showAlert(title:"提示",message:"用户名不能为空,请继续输入!")
            
        }else{
                if (passwordText.text  == nil) || (passwordText.text  == "" ) {
                    
                    showAlert(title:"提示",message:"密码不能为空,请继续输入!")
            }
            
                else{
                    
                    //获取输入框内容
                    let Name = accountText.text!
                    let Password = passwordText.text!
                    
                    let request = NSMutableURLRequest(url: URL(string: "http://localhost:8888/CampusToday/registration/registrationevents.php?Name=\(Name)&password=\(Password)")!)
                    
                    let task = URLSession.shared.dataTask(with: request as URLRequest) {
                        data, response, error in
                        
                        
                     //  print("response = \(String(describing: response))")
                        
                       let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                       print("responseString = \(String(describing: responseString))")
                    }
                    task.resume()
                        showAlert(title: "提示", message: "注册成功!")
            }
         
        }
   }
    
    

    @IBAction func Backlogin(_ sender: UIBarButtonItem) {
        
        let LoginVC = storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! ViewController
        LoginVC.modalPresentationStyle = .fullScreen
        present(LoginVC, animated: true) {
            print("跳转到登录页面...")
        }
        
    }
    

    
}
