//
//  SearchPersonViewController.swift
//  CampusToday
//
//  Created by 2 on 2021/1/5.
//  Copyright © 2021 iflytek. All rights reserved.
//

import UIKit
/*
UISearchController基本使用步骤：
1：初始化UISearchController，指定搜索结果视图控制器，设置相应的属性
2：设置代理，遵守UISearchResultsUpdating 协议
3：实现协议方法，更新搜索结果页面内容
*/
class SearchPersonViewController: UIViewController ,UITableViewDataSource, UITableViewDelegate,UISearchResultsUpdating{
    
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
    var dataArrayname:[String] = []
    var dataArrayaccount:[String] = []
    // 搜索控制器
    var searchController: UISearchController!
   //展示列表
    var tableView = UITableView()
    //搜索过滤后的结果集
    var searchArray:[String] = [String](){
        didSet {self.tableView.reloadData()}
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutviews()
        setBackItem()
        
        connectDatabase()
        selectData()
        
}
    
    func setBackItem() {
        // 1, 隐藏原来的返回按钮
        navigationItem.hidesBackButton = true
        // 2, 创建具备返回功能的按钮
        let backItem = UIBarButtonItem(title: "返回", style: .plain, target: self, action: #selector(back(sender:)))
        // 3, 将新建的按钮指定给返回按钮
        navigationItem.leftBarButtonItem = backItem
        

    }
    
    @objc func back(sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
    
    
    
  func layoutviews(){
    // 初始化搜索控制器
    self.searchController = UISearchController(searchResultsController: nil)
    self.searchController.searchResultsUpdater = self as? UISearchResultsUpdating
    self.searchController.dimsBackgroundDuringPresentation = false
    
    // 将搜索控制器集成到导航栏上
    
    if #available(iOS 11.0, *) {
        navigationItem.searchController = self.searchController
    } else {
        // Fallback on earlier versions
    }
    
    //创建表视图
    let tableViewFrame = CGRect(x: 0, y: 20, width: self.view.frame.width,height: self.view.frame.height-20)
    self.tableView = UITableView(frame: tableViewFrame, style:.plain)
    self.tableView.delegate = self as UITableViewDelegate
    self.tableView.dataSource = self as UITableViewDataSource
    //创建一个重用的单元格
    self.tableView.register(UITableViewCell.self,forCellReuseIdentifier: "MyCell")
    self.view.addSubview(self.tableView)
    
    }
    
    
    func updateSearchResults(for searchController: UISearchController) {
        //实时进行搜索
        func updateSearchResults(for searchController: UISearchController) {
            self.searchArray = self.dataArrayname.filter { (name) -> Bool in
            return name.contains(searchController.searchBar.text!)
            }
        }
        
    }
    
    
    
    
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            
            return self.dataArrayname.count
     
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)-> UITableViewCell {
                //为了提供表格显示性能，已创建完成的单元需重复使用
                let identify:String = "MyCell"
                //同一形式的单元格重复使用，在声明时已注册
                let cell = tableView.dequeueReusableCell(withIdentifier: identify,for: indexPath)
                if self.searchController.isActive {
                    cell.textLabel?.text = self.dataArrayname[indexPath.row]
                    return cell
                } else {
                    cell.textLabel?.text = self.dataArrayname[indexPath.row]
                    return cell
                }
                
        }
    
    
    //MARK:数据操作-----------------------------------------
    
    func connectDatabase(){
        let dataFilePath = URL(fileURLWithPath: getDocumentsDirectory()).appendingPathComponent("database.sqlite")
        if sqlite3_open(dataFilePath.absoluteString, &database) != SQLITE_OK {
            sqlite3_close(database)
            print("数据库无法打开")
        }
    }
    
    func selectData(){
        
        let sql = "SELECT * FROM contacts "
        var statement:OpaquePointer? = nil
        if sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK {
            
            while sqlite3_step(statement) == SQLITE_ROW {
                let NameValue = sqlite3_column_text(statement, 1)
                let Name = String(cString: UnsafePointer(NameValue!))
                let AccountValue = sqlite3_column_text(statement, 2)
                let Account = String(cString: UnsafePointer( AccountValue!))
                dataArrayname.append(Name)
                dataArrayaccount.append(Account)
                
            }
            sqlite3_finalize(statement)
            
        }
    }
    
    
    //获取Documents文档路径
    func getDocumentsDirectory() -> String {
        
        let documentDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
        print(documentDir)
        
        return documentDir
    }
    
    
    
    


}

