//
//  BQViewController.swift
//  CampusToday
//
//  Created by 2 on 2021/1/1.
//  Copyright © 2021 iflytek. All rights reserved.
//

import UIKit
import SnapKit



class AddNewBQViewController: UIViewController {
    var BianQianText = UITextField()
    var BianQian2Text = UITextField()
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
     var HUD: MBProgressHUD?
    var image = UIImageView()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutViews()
        setBackItem()
        setNavigationBar()
        //打开数据库
        connectDatabase()
        
      // 创建一张表NoteRecords( Title , Content)
        createTable()
        //查询数据
        selectData()
}
//MARK:布局----------------------------------
    
    func layoutViews(){
        BianQianText.layer.cornerRadius = 5
        BianQianText.clipsToBounds = true
       // BianQianText.placeholder = "  请输入新便签"
        //字体大小
        BianQianText.attributedPlaceholder = NSAttributedString.init(string:"请输入新便签", attributes: [NSAttributedString.Key.font:UIFont.systemFont(ofSize:25)])

        BianQianText.backgroundColor = .white
        view.addSubview(BianQianText)
        BianQianText.snp.makeConstraints { (maker) in
            maker.top.equalToSuperview()
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.4)
        }

        
//        BianQian2Text.layer.cornerRadius = 5
//        BianQian2Text.clipsToBounds = true
//        BianQian2Text.placeholder = "  标题"
//        BianQian2Text.backgroundColor = .white
//        view.addSubview(BianQian2Text)
//        BianQian2Text.snp.makeConstraints { (maker) in
//            maker.top.equalTo(SCREEN_HEIGHT*0.1)
//            maker.width.equalTo(SCREEN_WIDTH*0.3)
//            maker.height.equalTo(SCREEN_HEIGHT*0.1)
//        }
        
  
        image.image = UIImage(named: "便签背景")
        image.alpha = 0.5
        view.addSubview(image)
        image.snp.makeConstraints { (maker) in
            maker.width.height.equalToSuperview()
        }
        
    }
    
    
    
    
    func setBackItem() {
        // 1, 隐藏原来的返回按钮
        navigationItem.hidesBackButton = true
        // 2, 创建具备返回功能的按钮
        let backItem = UIBarButtonItem(title: "返回", style: .plain, target: self, action: #selector(back(sender:)))
        // 3, 将新建的按钮指定给返回按钮
        navigationItem.leftBarButtonItem = backItem
        
    }
    
    @objc func back(sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
    
    
    
    func setNavigationBar() {
        // 1, 创建导航栏右按钮
        let rightItem = UIBarButtonItem(title: "确认", style: .plain, target: self, action: #selector(rightItemOnclick(sender:)))
        navigationItem.rightBarButtonItem = rightItem
        navigationController?.navigationBar.barTintColor = UIColor(red: 112/255.0, green: 200/255.0, blue: 240/255.0, alpha: 1.0)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.titleTextAttributes = [
            // 1, 设置字号大小
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20),
            // 2, 设置文本颜色
            NSAttributedString.Key.foregroundColor: UIColor.white,
        ]
        
        
    }
    
    
    
    //MBP..弹窗
    func showAlert(title:String,message:String){
        HUD = MBProgressHUD(view:view)
        view.addSubview(HUD!)
        HUD?.mode = MBProgressHUDModeText
        HUD?.labelText = title
        HUD?.detailsLabelText = message
        HUD?.show(animated: true, whileExecuting: {
            sleep(3)
        }, completionBlock:{
            self.HUD?.removeFromSuperview()
            self.HUD = nil
        })
    }
    
    
    
    
    
  //MARK:数据操作----------------------------------

    
    @objc func rightItemOnclick(sender: UIBarButtonItem) {
        
        //获取输入框内容
        let Title = BianQianText
       // let Content = BianQian2Text
        
        if(BianQianText.text=="")||(BianQianText.text==nil){
            
            showAlert(title: "提示", message: "输入为空,请继续输入!")
        }
        else{
            //插入绑定值
            let sql = "INSERT INTO NoteRecords(Title, Content) VALUES(?,?)"
            var statement: OpaquePointer? = nil
            if sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK {
                
                let cTitle = Title.text!.cString(using: String.Encoding.utf8)!
                //let cContent = Content.text!.cString(using: String.Encoding.utf8)!
                
                sqlite3_bind_text(statement, 1, cTitle, -1, nil)
               // sqlite3_bind_text(statement, 2, cContent, -1, nil)
                
            }
            
            if sqlite3_step(statement) != SQLITE_DONE {
                print("Fail to Insert!")
            }
            sqlite3_finalize(statement)
            
            
        //添加成功添加弹窗
        let AlertVC = UIAlertController(title: "提示", message: "添加成功", preferredStyle: .alert)
        // let AlertVC = UIAlertController(title: "弹出提示", message: "这是个弹出框", preferredStyle: .actionSheet)
        
        let SureAction = UIAlertAction(title: "确定", style: .default) { (action) in
            print(action.title!)
            //跳转页面
            self.navigationController?.popViewController(animated: true)
        }
        AlertVC.addAction(SureAction)
        self.present(AlertVC, animated: true, completion: nil)
        }
    }
    
    

    
    //打开数据库
    func connectDatabase(){
        let dataFilePath = URL(fileURLWithPath: getDocumentsDirectory()).appendingPathComponent("database.sqlite")
        
        if sqlite3_open(dataFilePath.absoluteString, &database) != SQLITE_OK {
            sqlite3_close(database)
            print("数据库无法打开")
        }
    }
    
    func createTable(){
        // 创建一张表NoteRecords( Title , Content)
        let createSQL = "CREATE TABLE IF NOT EXISTS NoteRecords(Id INTEGER PRIMARY KEY AUTOINCREMENT,Title TEXT, Content TEXT)"
        
        
        var errMSG: UnsafeMutablePointer<Int8>? = nil
        
        _ = sqlite3_exec(database, createSQL, nil, nil, &errMSG)
    }
    
    
    //查询数据
    func selectData(){
        let sql = "SELECT * FROM NoteRecords "
        var statement:OpaquePointer? = nil
        if sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let TitleValue = sqlite3_column_text(statement, 1)
                _ = String(cString: UnsafePointer(TitleValue!))
               // let ContentValue = sqlite3_column_text(statement, 2)
              //  _ = String(cString: UnsafePointer( ContentValue!))
            }
            sqlite3_finalize(statement)

        }
        
    }
    
    
    
    
    
    //获取Documents文档路径
    func getDocumentsDirectory() -> String {
        
        let documentDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
        print(documentDir)
        
        return documentDir
    }
    
    
    

    
    
    
   
    
    
//    @objc func rightItemOnclick(sender: UIBarButtonItem) {
//
//
//
//
//
//
//    }
//
    
    
    
    
    
    
    
    
    
    
    
    
}
