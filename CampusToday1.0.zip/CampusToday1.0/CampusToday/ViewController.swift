//
//  ViewController.swift
//  UIDemo1
//
//  Created by HumbertCheung on 2020/9/22.
//  Copyright © 2020 HumbertCheung. All rights reserved.
//

import UIKit
import SnapKit


let SCREEN_HEIGHT = UIScreen.main.bounds.size.height
let SCREEN_WIDTH = UIScreen.main.bounds.size.width

class ViewController: UIViewController {
    
    var HUD: MBProgressHUD?
    var BG = UIImageView()
    var accountText = UITextField()
    var passwordText = UITextField()
    var loginBtn = UIButton()
    var registerBtn = UIButton()
    var forgetBtn = UIButton()
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        loadSettings()
    }
    
    
//MARK:布局-----------------------------------
    
    
    func showAlert(title:String,message:String){
        HUD = MBProgressHUD(view:view)
        view.addSubview(HUD!)
        HUD?.mode = MBProgressHUDModeText
        HUD?.labelText = title
        HUD?.detailsLabelText = message
        HUD?.show(animated: true, whileExecuting: {
            sleep(2)
        }, completionBlock:{
            self.HUD?.removeFromSuperview()
            self.HUD = nil
        })
    }
    

    
    
    func loadSettings(){
//        let userDefaults = UserDefaults.standard
//        let account = userDefaults.object(forKey: "account") as!String
//        let pwd = userDefaults.object(forKey: "password") as!String
//        accountText.text = account
//        passwordText.text = pwd
        passwordText.isSecureTextEntry = true
      
        
            }
  
    
    func layoutView() {
        BG.image = UIImage(named: "今日校园")
        view.addSubview(BG)
       BG.snp.makeConstraints { (maker) in
        
            maker.top.equalToSuperview()
        
            maker.width.height.equalToSuperview()
        }
        
        
        
        // 设置圆角
        accountText.layer.cornerRadius = 5
        accountText.clipsToBounds = true
        // 设置占位符
        accountText.placeholder = "  请输入用户名"
        accountText.backgroundColor = .white
        view.addSubview(accountText)
        accountText.snp.makeConstraints { (maker) in
            maker.top.equalToSuperview().offset(SCREEN_HEIGHT*0.5)
            maker.centerX.equalToSuperview().offset(SCREEN_WIDTH*0.3)
            maker.left.equalToSuperview().offset(SCREEN_WIDTH*0.2)
            maker.right.equalToSuperview().inset(SCREEN_WIDTH*0.2)
            maker.height.equalTo(SCREEN_HEIGHT*0.05)
        }
        
       
        
        // 密码框
        passwordText.layer.cornerRadius = 5
        passwordText.clipsToBounds = true
        passwordText.placeholder = "  请输入密码"
        passwordText.backgroundColor = .white
        view.addSubview(passwordText)
        passwordText.snp.makeConstraints { (maker) in
            maker.top.equalTo(accountText.snp.bottom).offset(SCREEN_HEIGHT*0.03)
            maker.centerX.left.right.height.equalTo(accountText)
        }

        // 登录按钮
        loginBtn.setTitle("登录", for: .normal)
        loginBtn.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        loginBtn.backgroundColor = UIColor(red: 250/255.0, green: 190/255.0, blue: 187/255.0, alpha: 1.0)
        loginBtn.layer.cornerRadius = 10
        loginBtn.clipsToBounds = true
        loginBtn.addTarget(self, action: #selector(loginOperation(sender:)), for: .touchUpInside)
        view.addSubview(loginBtn)
        loginBtn.snp.makeConstraints { (maker) in
            maker.top.equalTo(passwordText.snp.bottom).offset(SCREEN_HEIGHT*0.06)
            maker.centerX.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT * 0.055)
            maker.width.equalTo(SCREEN_WIDTH * 0.8)
        }
        
        // 注册按钮
        registerBtn.setTitle("立即注册", for: .normal)
       // registerBtn.setTitleColor( .black, for: .normal)
        registerBtn.layer.cornerRadius = 10
        registerBtn.clipsToBounds = true
        registerBtn.addTarget(self, action: #selector(RegistrationOperation(sender:)), for: .touchUpInside)
       view.addSubview(registerBtn)
        registerBtn.snp.makeConstraints { (maker) in
            maker.top.equalTo(loginBtn.snp.bottom).offset(SCREEN_HEIGHT*0.03)
            maker.centerX.height.equalTo(loginBtn)
            maker.width.equalTo(SCREEN_HEIGHT*0.2)
            maker.left.equalTo(SCREEN_WIDTH*0.6)
            
        }
        
        let str1 = NSMutableAttributedString(string: "立即注册")
        let range1 = NSRange(location: 0, length: str1.length)
        let number = NSNumber(value:NSUnderlineStyle.single.rawValue)//此处需要转换为NSNumber 不然不对,rawValue转换为integer
        str1.addAttribute(NSAttributedString.Key.underlineStyle, value: number, range: range1)
        str1.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.gray, range: range1)
        self.registerBtn.setAttributedTitle(str1, for: UIControl.State.normal)
     
        
        //忘记密码
        forgetBtn.setTitle("忘记密码", for: .normal)
        forgetBtn.layer.cornerRadius = 10
        forgetBtn.clipsToBounds = true
        //forgetBtn.addTarget(self, action: #selector(RegistrationOperation(sender:)), for: .touchUpInside)
        view.addSubview(forgetBtn)
        forgetBtn.snp.makeConstraints { (maker) in
            maker.top.equalTo(loginBtn.snp.bottom).offset(SCREEN_HEIGHT*0.03)
            maker.height.equalTo( registerBtn)
            maker.width.equalTo(SCREEN_WIDTH*0.2)
            maker.left.equalToSuperview().offset(SCREEN_WIDTH*0.1)
            
        }
        
        let str2 = NSMutableAttributedString(string: "忘记密码")
        let range2 = NSRange(location: 0, length: str2.length)
        let number1 = NSNumber(value:NSUnderlineStyle.single.rawValue)//此处需要转换为NSNumber 不然不对,rawValue转换为integer
        str2.addAttribute(NSAttributedString.Key.underlineStyle, value: number1, range: range2)
        str2.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.gray, range: range2)
        self.forgetBtn.setAttributedTitle(str2, for: UIControl.State.normal)
        
     
        
    }
   
    //MARK:PHP数据、点击跳转事件----------------
    
    
    //注册按钮事件
    @objc func RegistrationOperation(sender: UIButton){
        let RegVC = storyboard?.instantiateViewController(withIdentifier: "RegVC") as! UINavigationController 
        RegVC.modalPresentationStyle = .fullScreen
        present(RegVC, animated: true) {
            print("跳转到注册页面...")
        }
        
    }

    
    
    // 登录按钮事件
    @objc func loginOperation(sender: UIButton) {
        let Name = accountText.text!
        let password = passwordText.text!
         //创建请求的URL
        let urlString = "http://localhost:8888/CampusToday/login/loginaction.php?Name=\(Name)&password=\(password)"
        let url = URL(string:urlString)
        //创建请求的URLSession对象
        let session = URLSession.shared
        
       //准备请求任务
        let task = session.dataTask(with: url!) { (data, urlResponse, error) in
            //将取得的响应数据转化字典
            let dataDic = (try? JSONSerialization.jsonObject(with:data!, options: .allowFragments)) as? [String:Any]
            let status = dataDic!["status"] as! String
                if status == "100001"{
                    print(dataDic!)
                    DispatchQueue.main.async {
                        let TabBarVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarVC") as! UITabBarController
                        TabBarVC.modalPresentationStyle = .fullScreen
                        self.present(TabBarVC, animated: true) {
                            print("跳转TabBar主页")
                        }
                    }
         
                }else if status == "-100002" {
                    DispatchQueue.main.async {
                        self.showAlert(title: "提示", message: "用户名或密码不存在")
                    }
                    
                }
  
        }
        //启动
        task.resume()
    }
    
   
}
