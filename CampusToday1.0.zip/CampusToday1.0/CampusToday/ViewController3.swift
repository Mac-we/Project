//
//  ViewController3.swift
//  CampusToday
//
//  Created by 2 on 2021/1/4.
//  Copyright © 2021 iflytek. All rights reserved.
//

import UIKit

//子视图控制器3
class ViewController3: UIViewController {
    var image = UIImageView()
    var image1 = UIImageView()
    var btn = UIButton()
    var myView = UIView()
    var label = UILabel()
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutviews()
        
    }
    
   
    func layoutviews(){
        
        view.backgroundColor = .white
        
        image.image = UIImage(named: "讲座")
        view.addSubview(image)
            image.snp.makeConstraints({ (maker) in
                maker.height.equalTo(SCREEN_HEIGHT*0.1)
                maker.width.equalTo(SCREEN_HEIGHT*0.2)
                maker.left.equalTo(SCREEN_WIDTH*0.55)
                maker.top.equalTo(view).offset(20)
            })
        
        image1.image = UIImage(named: "讲座2")
        myView.addSubview(image1)
        image1.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_HEIGHT*0.2)
            maker.right.equalToSuperview().offset(-SCREEN_WIDTH*0.05)
            maker.top.equalToSuperview()
        })
        
        
        let date = NSDate()
        let dateFormatter = DateFormatter()
        //日期显示格式，可按自己需求显示
        dateFormatter.dateFormat = "yyy-MM-dd-eeee"
        let strNowTime = dateFormatter.string(from: date as Date) as String
        btn.titleLabel?.numberOfLines = 0
        btn.titleLabel?.lineBreakMode = .byWordWrapping
        btn.setTitle("[行业讲座]5G赋能千行百业\(strNowTime)", for: .normal)
        btn.setTitleColor(.black , for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        btn.addTarget(self, action: #selector(newsone(sender:)), for: .touchUpInside)
        view.addSubview(btn)
        btn.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_WIDTH*0.5)
            maker.left.equalToSuperview().offset(SCREEN_WIDTH*0.05)
            maker.top.equalTo(view)
        })
        

        label.text = "【学术讲座】关于举办“国际化视野与体验”讲座的通知\(strNowTime)"
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        myView.addSubview(label)
        label.snp.makeConstraints { (maker) in
            maker.top.equalToSuperview()
            maker.left.equalToSuperview()
            maker.width.equalTo(SCREEN_WIDTH*0.5)
        }
        
       
        
        
        
        //创建手势识别器
        let dbTapGesture = UITapGestureRecognizer(target: self, action: #selector(dbTapGestureOperation(tap:)))
        //设置触摸点数
        dbTapGesture.numberOfTouchesRequired = 1
        //单机
        dbTapGesture.numberOfTapsRequired = 1
        myView.addGestureRecognizer(dbTapGesture)
        view.addSubview(myView)
        myView.snp.makeConstraints({ (maker) in
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.left.equalToSuperview().offset(SCREEN_WIDTH*0.025)
            maker.top.equalTo(btn.snp.bottom).offset(SCREEN_HEIGHT*0.1)
        })
        
       
        
        
        
        
        
        }
    
    
    @objc func dbTapGestureOperation(tap:UITapGestureRecognizer){
        print("触发点击")
        let AlertVC = UIAlertController(title: "提示", message: "功能暂未实现,尽情期待", preferredStyle: .alert)
        // let AlertVC = UIAlertController(title: "弹出提示", message: "这是个弹出框", preferredStyle: .actionSheet)
        
        let SureAction = UIAlertAction(title: "确定", style: .default) { (action) in
            print(action.title!)
        }
        
        let DenyAction = UIAlertAction(title: "取消", style: .destructive) { (action) in
            print(action.title!)
        }
        
        AlertVC.addAction(SureAction)
        AlertVC.addAction(DenyAction)
        self.present(AlertVC, animated: true, completion: nil)
        
    }
    
    
    
    
    
    
    
    
    @objc func newsone(sender:UIButton){
        let AlertVC = UIAlertController(title: "提示", message: "功能暂未实现,尽情期待", preferredStyle: .alert)
        // let AlertVC = UIAlertController(title: "弹出提示", message: "这是个弹出框", preferredStyle: .actionSheet)
        
        let SureAction = UIAlertAction(title: "确定", style: .default) { (action) in
            print(action.title!)
        }

        let DenyAction = UIAlertAction(title: "取消", style: .destructive) { (action) in
            print(action.title!)
        }
        
        AlertVC.addAction(SureAction)
        AlertVC.addAction(DenyAction)
        self.present(AlertVC, animated: true, completion: nil)
 
    }
        
        
    
    
        
        
    }


