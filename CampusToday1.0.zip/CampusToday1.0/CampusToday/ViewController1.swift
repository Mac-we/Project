//
//  ViewController1.swift
//  CampusToday
//
//  Created by 2 on 2021/1/4.
//  Copyright © 2021 iflytek. All rights reserved.
//
import UIKit
import SnapKit
//子视图控制器1
class ViewController1: UIViewController {
   
    
    
    var image = UIImageView()
    var image1 = UIImageView()
    var image2 = UIImageView()
    var image3 = UIImageView()
    var image4 = UIImageView()
    var image5 = UIImageView()
    
    var myView = UIView()
    var label = UILabel()
    var label1 = UILabel()
    var label2 = UILabel()
    var label3 = UILabel()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutviews()
        
    }
    
    func layoutviews(){
        
        let date = NSDate()
        let dateFormatter = DateFormatter()
        //日期显示格式，可按自己需求显示
        dateFormatter.dateFormat = "yyy-MM-dd-eeee"
        let strNowTime = dateFormatter.string(from: date as Date) as String
        
        image.image = UIImage(named: "自我认知")
        myView.addSubview(image)
        image.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_WIDTH*0.28)
            maker.left.equalToSuperview()
            maker.top.equalToSuperview().offset(30)
        })
        
        image1.image = UIImage(named: "生活情况")
        myView.addSubview(image1)
        image1.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_WIDTH*0.28)
            maker.left.equalTo(image.snp.right).offset(SCREEN_WIDTH*0.05)
            maker.top.equalToSuperview().offset(30)
        })
        
        image2.image = UIImage(named: "见面会")
        myView.addSubview(image2)
        image2.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_WIDTH*0.28)
            maker.left.equalTo(image1.snp.right).offset(SCREEN_WIDTH*0.05)
            maker.top.equalToSuperview().offset(30)
        })
        
        image3.image = UIImage(named: "征兵1")
        myView.addSubview(image3)
        image3.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_WIDTH*0.28)
            maker.left.equalToSuperview()
            maker.top.equalTo(image.snp.bottom).offset(60)
        })
        
        image4.image = UIImage(named: "征兵2")
        myView.addSubview(image4)
        image4.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_WIDTH*0.28)
            maker.left.equalTo(image.snp.right).offset(SCREEN_WIDTH*0.05)
          maker.top.equalTo(image.snp.bottom).offset(60)
        })
        
        image5.image = UIImage(named: "征兵3")
        myView.addSubview(image5)
        image5.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_WIDTH*0.28)
            maker.left.equalTo(image1.snp.right).offset(SCREEN_WIDTH*0.05)
            maker.top.equalTo(image.snp.bottom).offset(60)
        })
  
        
        label.text = "人生规划定目标  亲助成长育人才"
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        myView.addSubview(label)
        label.snp.makeConstraints { (maker) in
            maker.top.equalToSuperview().offset(5)
        }
        
        label1.text = "\(strNowTime)"
        myView.addSubview(label1)
        label1.snp.makeConstraints { (maker) in
            maker.top.equalTo(image.snp.bottom)
        }
        

        
        label2.text = "投笔从戎终不悔 献身国防写青春"
        label2.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        myView.addSubview(label2)
        label2.snp.makeConstraints { (maker) in
            maker.top.equalTo(label1.snp.bottom).offset(10)
        }
        
        label3.text = "\(strNowTime)"
        myView.addSubview(label3)
        label3.snp.makeConstraints { (maker) in
            maker.top.equalTo(image3.snp.bottom)
        }
        
        
        
        
       
    //创建手势识别器
        let dbTapGesture = UITapGestureRecognizer(target: self, action: #selector(dbTapGestureOperation(tap:)))
        //设置触摸点数
        dbTapGesture.numberOfTouchesRequired = 1
        //单机
        dbTapGesture.numberOfTapsRequired = 1
        myView.addGestureRecognizer(dbTapGesture)
        view.addSubview(myView)
        myView.snp.makeConstraints({ (maker) in
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.3)
            maker.left.equalToSuperview().offset(SCREEN_WIDTH*0.025)
            maker.top.equalTo(view)
        })
        
    }
    
    
    @objc func dbTapGestureOperation(tap:UITapGestureRecognizer){
        print("触发点击")
        let AlertVC = UIAlertController(title: "提示", message: "功能暂未实现,尽情期待", preferredStyle: .alert)
        // let AlertVC = UIAlertController(title: "弹出提示", message: "这是个弹出框", preferredStyle: .actionSheet)
        
        let SureAction = UIAlertAction(title: "确定", style: .default) { (action) in
            print(action.title!)
        }
        
        let DenyAction = UIAlertAction(title: "取消", style: .destructive) { (action) in
            print(action.title!)
        }
        
        AlertVC.addAction(SureAction)
        AlertVC.addAction(DenyAction)
        self.present(AlertVC, animated: true, completion: nil)
        
    }
    
    
    
  
    
    
}
