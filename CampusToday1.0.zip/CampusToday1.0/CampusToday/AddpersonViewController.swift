//
//  BQViewController.swift
//  CampusToday
//
//  Created by 2 on 2021/1/1.
//  Copyright © 2021 iflytek. All rights reserved.
//

import UIKit
import SnapKit



class AddpersonViewController: UIViewController {
    
    
    var nameText = UITextField()
    var accountText = UITextField()
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
    var HUD: MBProgressHUD?
    var image = UIImageView()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutViews()
       
        
        
    }
     //MARK:布局------------------------------
    
    func layoutViews(){

        setBackItem()
        //1、打开数据库
        connectDatabase()
        //2、创建表
        createTable()
        //4、查询数据
        selectData()
        setNavigationBar()

        
        image.alpha = 0.5
        image.image = UIImage(named: "便签背景")
        view.addSubview(image)
        image.snp.makeConstraints { (maker) in
            
            maker.top.equalToSuperview()
            
            maker.height.equalTo(SCREEN_HEIGHT)
            maker.width.equalTo(SCREEN_WIDTH)
        }
        
      nameText.attributedPlaceholder = NSAttributedString.init(string:"请输入新联系人", attributes: [NSAttributedString.Key.font:UIFont.systemFont(ofSize:25)])
        nameText.layer.cornerRadius = 5
        nameText.clipsToBounds = true
        //nameText.placeholder = " 请输入新联系人"
        nameText.backgroundColor = .white
        view.addSubview(nameText)
        nameText.snp.makeConstraints { (maker) in
            maker.top.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
        }
        
        accountText.attributedPlaceholder = NSAttributedString.init(string:"账号", attributes: [NSAttributedString.Key.font:UIFont.systemFont(ofSize:25)])
        accountText.layer.cornerRadius = 5
        accountText.clipsToBounds = true
        //accountText.placeholder = "  账号"
        accountText.backgroundColor = .white
        view.addSubview(accountText)
        accountText.snp.makeConstraints { (maker) in
            maker.top.equalTo(SCREEN_HEIGHT*0.2)
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
        }
        
        
        
        
    }
    func setBackItem() {
        // 1, 隐藏原来的返回按钮
        navigationItem.hidesBackButton = true
        // 2, 创建具备返回功能的按钮
        let backItem = UIBarButtonItem(title: "返回", style: .plain, target: self, action: #selector(back(sender:)))
        // 3, 将新建的按钮指定给返回按钮
        navigationItem.leftBarButtonItem = backItem
        
    }
    
    
    
    @objc func back(sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
        
    }
    
    

    func setNavigationBar() {
        // 1, 创建导航栏右按钮
        let rightItem = UIBarButtonItem(title: "确认", style: .plain, target: self, action: #selector(rightItemOnclick(sender:)))
        navigationItem.rightBarButtonItem = rightItem
        navigationController?.navigationBar.barTintColor = UIColor(red: 112/255.0, green: 200/255.0, blue: 240/255.0, alpha: 1.0)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.titleTextAttributes = [
            // 1, 设置字号大小
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20),
            // 2, 设置文本颜色
            NSAttributedString.Key.foregroundColor: UIColor.white,
        ]
    }
    
 
    

    
    func showAlert(title:String,message:String){
        HUD = MBProgressHUD(view:view)
        view.addSubview(HUD!)
        HUD?.mode = MBProgressHUDModeText
        HUD?.labelText = title
        HUD?.detailsLabelText = message
        HUD?.show(animated: true, whileExecuting: {
            sleep(3)
        }, completionBlock:{
            self.HUD?.removeFromSuperview()
            self.HUD = nil
        })
    }
    
    
    //MARK:数据操作--------------------------
  
    
    
    //打开数据库
    func connectDatabase(){
        let dataFilePath = URL(fileURLWithPath: getDocumentsDirectory()).appendingPathComponent("database.sqlite")
        
        if sqlite3_open(dataFilePath.absoluteString, &database) != SQLITE_OK {
            sqlite3_close(database)
            print("数据库无法打开")
        }
    }

    func createTable(){
        // 创建一张表contacts( Name, Phone,password)
        let createSQL = "CREATE TABLE IF NOT EXISTS contacts(Id INTEGER PRIMARY KEY AUTOINCREMENT,Name TEXT,  Account TEXT)"


        var errMSG: UnsafeMutablePointer<Int8>? = nil

        _ = sqlite3_exec(database, createSQL, nil, nil, &errMSG)
    }


    //查询数据
    func selectData(){
        let sql = "SELECT * FROM contacts "
        var statement:OpaquePointer? = nil
        if sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let nameValue = sqlite3_column_text(statement, 1)
                _ = String(cString: UnsafePointer(nameValue!))
                let accountValue = sqlite3_column_text(statement, 2)
                _ = String(cString: UnsafePointer( accountValue!))
            }
            sqlite3_finalize(statement)

        }

    }

//点击事件,添加联系人
    @objc func rightItemOnclick(sender: UIBarButtonItem) {
        
        //获取输入框内容
        let Name = nameText
        let Account = accountText
        
        //插入绑定值
        let sql = "INSERT INTO contacts(Name, Account) VALUES(?,?)"
        
        if(nameText.text! == "")||(accountText.text! == ""){
        showAlert(title: "提示", message: "添加失败!")
        }else{
            //插入数据到数据库
            var statement: OpaquePointer? = nil
            if sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK {
                let cName = Name.text!.cString(using: String.Encoding.utf8)!
                let cAccount = Account.text!.cString(using: String.Encoding.utf8)!
                sqlite3_bind_text(statement, 1, cName, -1, nil)
                sqlite3_bind_text(statement, 2, cAccount, -1, nil)
                
            }
            
            if sqlite3_step(statement) != SQLITE_DONE {
                print("Fail to Insert!")
            }
            sqlite3_finalize(statement)
            //添加成功添加弹窗
            let AlertVC = UIAlertController(title: "提示", message: "添加成功", preferredStyle: .alert)
            // let AlertVC = UIAlertController(title: "弹出提示", message: "这是个弹出框", preferredStyle: .actionSheet)
            
            let SureAction = UIAlertAction(title: "确定", style: .default) { (action) in
                print(action.title!)
                //跳转页面
              self.navigationController?.popViewController(animated: true)
            }
            AlertVC.addAction(SureAction)
            self.present(AlertVC, animated: true, completion: nil)
           
            
            
        }

    }

    //获取Documents文档路径
    func getDocumentsDirectory() -> String {

        let documentDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]

        print(documentDir)

        return documentDir
    }



  
    
    
    
    
}

