

import UIKit
import SnapKit



class TongXunViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var tableView = UITableView()
    
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
    var dataArrayname:[String] = []
    var dataArrayaccount:[String] = []
    
    var image = UIImageView()
    var barButtonItem = UIBarButtonItem()
    let refreshControl = UIRefreshControl()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutViews()
        setNavigationBar()
        connectDatabase()
        selectData()
    }
    

    
       //MARK:布局----------------------------
    
    func setNavigationBar() {
        // 1, 创建导航栏右按钮
        let rightItem = UIBarButtonItem(title: "", style: .plain, target: self, action: #selector(rightItemOnclick(sender:)))
        navigationItem.rightBarButtonItem = rightItem
        rightItem.setBackgroundImage(UIImage(named: "添加朋友"), for: .normal, barMetrics: .default)
        navigationController?.navigationBar.barTintColor = UIColor(red: 112/255.0, green: 200/255.0, blue: 240/255.0, alpha: 1.0)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.titleTextAttributes = [
            // 1, 设置字号大小
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20),
            // 2, 设置文本颜色
            NSAttributedString.Key.foregroundColor: UIColor.white,
        ]
        
        let leftItem = UIBarButtonItem(title: "", style: .plain, target: self, action: #selector(leftItemOnclick(sender:)))
        leftItem.setBackgroundImage(UIImage(named: "搜索联系人"), for: .normal, barMetrics: .default)
        navigationItem.leftBarButtonItem = leftItem
        navigationController?.navigationBar.barTintColor = UIColor(red: 112/255.0, green: 200/255.0, blue: 240/255.0, alpha: 1.0)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.titleTextAttributes = [
            // 1, 设置字号大小
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20),
            // 2, 设置文本颜色
            NSAttributedString.Key.foregroundColor: UIColor.white,
        ]
        
      
        
    }
    
    @objc func rightItemOnclick(sender: UIBarButtonItem) {
        // 1, 获取设置控制器
        let addpersonVC = storyboard?.instantiateViewController(withIdentifier: "addpersonVC")
        addpersonVC?.title = "添加联系人"
        // 2, 将获取到的控制器推入导航栈(即跳转到新控制器)
        navigationController?.pushViewController(addpersonVC!, animated: true)
    }
    
    @objc func leftItemOnclick(sender: UIBarButtonItem) {
        // 1, 获取设置控制器
        let SearchVC = storyboard?.instantiateViewController(withIdentifier: "SearchVC")
        SearchVC?.title = "搜索联系人"
        // 2, 将获取到的控制器推入导航栈(即跳转到新控制器)
        navigationController?.pushViewController(SearchVC!, animated: true)
    }
  
    
    func layoutViews() {
      
        
        tableView.rowHeight = 100
       // self.tableView = UITableView.init(frame: self.view.frame, style: .plain)
        //tableView.alpha = 0.5
        self.tableView.delegate = self
        self.tableView.dataSource = self
         view.addSubview(tableView)
        tableView.snp.makeConstraints { (maker) in
            maker.size.left.top.equalToSuperview()
        }
        //刷新控件
        tableView.refreshControl = refreshControl
        refreshControl.backgroundColor = UIColor.gray
        refreshControl.attributedTitle = NSAttributedString(string: "刷新一下：\(NSDate())", attributes: [NSAttributedString.Key.foregroundColor:UIColor.white])//设置文字颜色
        refreshControl.tintColor = UIColor.gray//小菊花的颜色
        refreshControl.tintAdjustmentMode = .dimmed //色彩调整模式
        refreshControl.addTarget(self, action: #selector(addcount), for: .valueChanged)
        
      
       
        
        image.alpha = 0.2
        image.image = UIImage(named: "便签背景")
        view.addSubview(image)
        image.snp.makeConstraints { (maker) in
            
            maker.top.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT)
            maker.width.equalTo(SCREEN_WIDTH)
        }
        
       
    }
    
    
    @objc func addcount(){
            selectData()
        self.tableView.reloadData()
        self.refreshControl.endRefreshing()

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int)
        -> Int {
            return dataArrayname.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)
        -> UITableViewCell {
            let identifier = "Cell"
            var cell = tableView.dequeueReusableCell(withIdentifier: identifier)
            if cell == nil {
                cell = UITableViewCell(style: .subtitle, reuseIdentifier: identifier)
            }
            
            cell?.textLabel?.text = dataArrayname[indexPath.row]
            cell?.detailTextLabel?.text = dataArrayaccount[indexPath.row]
            
            cell?.textLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
            cell?.detailTextLabel?.font = UIFont.systemFont(ofSize: 18)
            
            cell?.accessoryType = .disclosureIndicator//小箭头
            cell?.accessoryType = UITableViewCell.AccessoryType.disclosureIndicator
            cell?.backgroundColor = UIColor(red: 242/255, green: 234/255, blue: 231/255, alpha: 1)
         
            let image = UIImage(named:"联系人 cell")
            cell?.imageView?.image = image
            return cell!
            
    }
    
     
    //把delete换成中文
    func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String? {
        return "删除"
    }
    
 //删除
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete {
            
            self.dataArrayname.remove(at: indexPath.row-1)
            //刷新tableview
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }

    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // 1, 获取设置控制器
        let CdVC = storyboard?.instantiateViewController(withIdentifier: "CdVC")
        CdVC?.title = "联系人详情"
        // 2, 将获取到的控制器推入导航栈(即跳转到新控制器)
        navigationController?.pushViewController(CdVC!, animated: true)
    }
    
    
 
    //MARK:数据处理-----------------------
    
    func connectDatabase(){
        
        let dataFilePath = URL(fileURLWithPath: getDocumentsDirectory()).appendingPathComponent("database.sqlite")
        if sqlite3_open(dataFilePath.absoluteString, &database) != SQLITE_OK {
            sqlite3_close(database)
            print("数据库无法打开")
        }
    }
    
    
    
    
    func selectData(){
        
        let sql = "SELECT * FROM contacts "
        var statement:OpaquePointer? = nil
        if sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK {
            
            while sqlite3_step(statement) == SQLITE_ROW {
                let NameValue = sqlite3_column_text(statement, 1)
                let Name = String(cString: UnsafePointer(NameValue!))
                let AccountValue = sqlite3_column_text(statement, 2)
                let Account = String(cString: UnsafePointer( AccountValue!))
                dataArrayname.append(Name)
                dataArrayaccount.append(Account)
                
            }
            
            sqlite3_finalize(statement)
            
        }
        
    }
    
    

    
    //获取Documents文档路径
    func getDocumentsDirectory() -> String {
        
        let documentDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
        print(documentDir)
        
        return documentDir
    }
    
    

    
    
    
    
}
