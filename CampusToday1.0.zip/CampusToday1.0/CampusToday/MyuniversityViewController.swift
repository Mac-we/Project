//
//  SettingsViewController.swift
//  050401-SnapKitLayout
//
//  Created by HumbertCheung on 2020/10/19.
//  Copyright © 2020 iflytek. All rights reserved.
//

import UIKit
//第三方分页视图控件
import PagingMenuController



class MyuniversityViewController: UIViewController {
      var img = UIImageView()
      var label = UILabel()
      var btn1 = UIButton()
      var btn2 = UIButton()
      var btn3 = UIButton()
    
   
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        setBackItem()
        layoutviews()
        
        
        //分页菜单配置
        let options = PagingMenuOptions()
        //分页菜单控制器初始化
        let pagingMenuController = PagingMenuController(options: options)
        //分页菜单控制器尺寸设置
        pagingMenuController.view.frame.origin.y += SCREEN_HEIGHT*0.48
        pagingMenuController.view.frame.size.height -= 100
        
        //建立父子关系
        addChild(pagingMenuController)
        //分页菜单控制器视图添加到当前视图中
        view.addSubview(pagingMenuController.view)
        

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    func  layoutviews(){
  
        img.image = UIImage(named: "安信工")
        view.addSubview(img)
        img.snp.makeConstraints { (maker) in
            maker.width.equalTo(SCREEN_WIDTH)
            maker.height.equalTo(SCREEN_HEIGHT*0.4)
        }
        
        
        label.text = "校内资讯"
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 25,weight:.bold)
        view.addSubview(label)
        label.snp.makeConstraints { (maker) in
            maker.top.equalTo(SCREEN_HEIGHT*0.42)
            maker.width.equalTo(SCREEN_WIDTH*0.4)
            maker.left.equalTo(SCREEN_WIDTH*0.05)
        }
        
        

        
    }
    
    
    //分页菜单配置
    private struct PagingMenuOptions: PagingMenuControllerCustomizable {
        //第1个子视图控制器
        private let viewController1 = ViewController1()
        //第2个子视图控制器
        private let viewController2 = ViewController2()
        //第3个子视图控制器
        private let viewController3 = ViewController3()
        //组件类型
        fileprivate var componentType: ComponentType {
            return .all(menuOptions: MenuOptions(), pagingControllers: pagingControllers)
        }
        
        //所有子视图控制器
        fileprivate var pagingControllers: [UIViewController] {
            return [viewController1, viewController2, viewController3]
        }
        
        //菜单配置项
        fileprivate struct MenuOptions: MenuViewCustomizable {
            //菜单显示模式
            var displayMode: MenuDisplayMode {
                return .segmentedControl
            }
            //菜单项
            var itemsOptions: [MenuItemViewCustomizable] {
                return [MenuItem1(), MenuItem2() ,MenuItem3()]
            }
        }
        
        //第1个菜单项
        fileprivate struct MenuItem1: MenuItemViewCustomizable {
            //自定义菜单项名称
            var displayMode: MenuItemDisplayMode {
                return .text(title: MenuItemText(text: "学院要闻"))
            }
        }
        
        //第2个菜单项
        fileprivate struct MenuItem2: MenuItemViewCustomizable {
            //自定义菜单项名称
            var displayMode: MenuItemDisplayMode {
                return .text(title: MenuItemText(text: "通知公告"))
            }
        }
    }
    //第3个菜单项
    fileprivate struct MenuItem3: MenuItemViewCustomizable {
        //自定义菜单项名称
        var displayMode: MenuItemDisplayMode {
            return .text(title: MenuItemText(text: "学术信息"))
        }
    }

    
    
    
    
    
    func setBackItem() {
        // 1, 隐藏原来的返回按钮
        navigationItem.hidesBackButton = true
        // 2, 创建具备返回功能的按钮
        let backItem = UIBarButtonItem(title: "返回", style: .plain, target: self, action: #selector(back(sender:)))
        // 3, 将新建的按钮指定给返回按钮
        navigationItem.leftBarButtonItem = backItem
     
    }
    
    @objc func back(sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }


    
    
    
}
