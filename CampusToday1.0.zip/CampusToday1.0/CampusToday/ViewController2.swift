//
//  ViewController2.swift
//  CampusToday
//
//  Created by 2 on 2021/1/4.
//  Copyright © 2021 iflytek. All rights reserved.
//
import UIKit

//子视图控制器2
class ViewController2: UIViewController {
 var image = UIImageView()
    var btn = UIButton()
    var btn1 = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutviews()
        
    }
    
    func layoutviews(){
        
        
        view.backgroundColor = .white
        
        image.image = UIImage(named: "晋升仪式")
        view.addSubview(image)
        image.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_HEIGHT*0.2)
            maker.left.equalTo(SCREEN_WIDTH*0.55)
            maker.top.equalTo(view).offset(20)
        })
        
        let date = NSDate()
        let dateFormatter = DateFormatter()
        //日期显示格式，可按自己需求显示
        dateFormatter.dateFormat = "yyy-MM-dd-eeee"
        let strNowTime = dateFormatter.string(from: date as Date) as String
        btn.titleLabel?.numberOfLines = 0
        btn.titleLabel?.lineBreakMode = .byWordWrapping
        btn.titleEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: 0);
        btn.setTitle("  芜湖市湾沚区征兵政策解读\(strNowTime)", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        btn.setTitleColor(.black, for: .normal)
        btn.addTarget(self, action: #selector(newsone(sender:)), for: .touchUpInside)
        btn.backgroundColor = UIColor(red: 250/255.0, green: 190/255.0, blue: 187/255.0, alpha:0)
        view.addSubview(btn)
        btn.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_WIDTH*0.5)
            maker.left.equalTo(SCREEN_WIDTH*0.05)
            maker.top.equalTo(view)
        })
        
        
 
        btn1.titleLabel?.numberOfLines = 0
        btn1.titleLabel?.lineBreakMode = .byWordWrapping
        btn1.titleEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: 0);
        btn1.setTitle("   安徽信息工程学院2020届毕业生就业质量年度报告\(strNowTime)", for: .normal)
        btn1.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        btn1.setTitleColor(.black, for: .normal)
        btn1.addTarget(self, action: #selector(newsone(sender:)), for: .touchUpInside)
        btn1.backgroundColor = UIColor(red: 250/255.0, green: 190/255.0, blue: 187/255.0, alpha:0)
        view.addSubview(btn1)
        btn1.snp.makeConstraints({ (maker) in
            maker.height.equalTo(SCREEN_HEIGHT*0.1)
            maker.width.equalTo(SCREEN_WIDTH*0.5)
            maker.left.equalTo(SCREEN_WIDTH*0.05)
            maker.top.equalTo(btn.snp.bottom).offset(50)
        })
        
        
        
        
        
        
    }
    
    @objc func newsone(sender:UIButton){
        let AlertVC = UIAlertController(title: "提示", message: "功能暂未实现,尽情期待", preferredStyle: .alert)
        // let AlertVC = UIAlertController(title: "弹出提示", message: "这是个弹出框", preferredStyle: .actionSheet)
        
        let SureAction = UIAlertAction(title: "确定", style: .default) { (action) in
            print(action.title!)
        }
        
        let DenyAction = UIAlertAction(title: "取消", style: .destructive) { (action) in
            print(action.title!)
        }
        
        AlertVC.addAction(SureAction)
        AlertVC.addAction(DenyAction)
        self.present(AlertVC, animated: true, completion: nil)
        
    }
    
    
    
    
}


