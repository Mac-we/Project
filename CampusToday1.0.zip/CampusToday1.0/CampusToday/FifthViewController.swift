//
//  FifthViewController.swift
//  CampusToday
//
//  Created by 2 on 2021/1/10.
//  Copyright © 2021 iflytek. All rights reserved.
//
import UIKit

//子视图控制器1
class FifthViewController: UIViewController {
    var MonDay = UILabel()
    var TuesDay = UILabel()
    var WednesDay = UILabel()
    var ThursDay = UILabel()
    var FriDay = UILabel()
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutviews()
        //1、打开数据库
        connectDatabase()
        //2、创建表
        createTable()
        //3、插入数据
        // prepareData()
        //4、查询数据
        selectData()
    }
    
    func layoutviews(){
        
        
        
        
        MonDay.textColor = .black
        MonDay.backgroundColor = .white
        MonDay.font = UIFont.systemFont(ofSize: 15,weight:.bold)
        view.addSubview(MonDay)
        MonDay.snp.makeConstraints { (maker) in
            maker.top.equalTo(view)
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.05)
        }
        
        
        view.addSubview(TuesDay)
        TuesDay.textColor = .black
        TuesDay.backgroundColor = .white
        TuesDay.font = UIFont.systemFont(ofSize: 15,weight:.bold)
        TuesDay.snp.makeConstraints { (maker) in
            maker.top.equalTo(view).offset(SCREEN_HEIGHT*0.05)
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.05)
        }
        
        
        view.addSubview(WednesDay)
        WednesDay.textColor = .black
        WednesDay.backgroundColor = .white
        WednesDay.font = UIFont.systemFont(ofSize: 15,weight:.bold)
        WednesDay.snp.makeConstraints { (maker) in
            maker.top.equalTo(view).offset(SCREEN_HEIGHT*0.1)
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.05)
        }
        
        
        view.addSubview(ThursDay)
        ThursDay.textColor = .black
        ThursDay.backgroundColor = .white
        ThursDay.font = UIFont.systemFont(ofSize: 15,weight:.bold)
        ThursDay.snp.makeConstraints { (maker) in
            maker.top.equalTo(view).offset(SCREEN_HEIGHT*0.15)
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.05)
        }
        
        
        view.addSubview(FriDay)
        FriDay.textColor = .black
        FriDay.backgroundColor = .white
        FriDay.font = UIFont.systemFont(ofSize: 15,weight:.bold)
        FriDay.snp.makeConstraints { (maker) in
            maker.top.equalTo(view).offset(SCREEN_HEIGHT*0.2)
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.05)
        }

        
        
        
        
        
        
        
    }
    
    
    //打开数据库
    func connectDatabase(){
        let dataFilePath = URL(fileURLWithPath: getDocumentsDirectory()).appendingPathComponent("database.sqlite")
        if sqlite3_open(dataFilePath.absoluteString, &database) != SQLITE_OK {
            sqlite3_close(database)
            print("数据库无法打开")
        }
    }
    
    func createTable(){
        // 创建一张表Timetable( Monday ,Tuesday ,Wednesday ,Thursday ,Friday)
        let createSQL = "CREATE TABLE IF NOT EXISTS Timetable(Id INTEGER PRIMARY KEY AUTOINCREMENT,Monday TEXT,Tuesday TEXT,Wednesday TEXT,Thursday TEXT,Friday TEXT)"
        var errMSG: UnsafeMutablePointer<Int8>? = nil
        
        _ = sqlite3_exec(database, createSQL, nil, nil, &errMSG)
    }
    
    //准备初始数据
    func prepareData() {
        let sql = "INSERT INTO Timetable(Monday ,Tuesday ,Wednesday ,Thursday ,Friday) VALUES ('上午1~4节:移动互联开发,下午1~2节:毛概','上午1~4节:移动互联开发,下午1~4节:移动互联开发','上午1~2节:移动互联开发','上午1~4节:移动互联开发,下午1~2节:软件工程','无')"
        var errMSG: UnsafeMutablePointer<Int8>? = nil
        _ = sqlite3_exec(database, sql, nil, nil, &errMSG)
        
    }
    
    
    //查询数据
    func selectData(){
        let sql = "SELECT  * FROM Timetable"
        var statement:OpaquePointer? = nil
        if sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK {
            
            
            while sqlite3_step(statement) == SQLITE_ROW {
                let MondayValue = sqlite3_column_text(statement, 1)
                let Monday = String(cString: UnsafePointer(MondayValue!))
                let TuesdayValue = sqlite3_column_text(statement, 2)
                let Tuesday = String(cString: UnsafePointer( TuesdayValue!))
                let WednesdayValue = sqlite3_column_text(statement, 3)
                let Wednesday = String(cString: UnsafePointer(WednesdayValue!))
                let ThursdayValue = sqlite3_column_text(statement, 4)
                let Thursday = String(cString: UnsafePointer( ThursdayValue!))
                let FridayValue = sqlite3_column_text(statement, 5)
                let Friday = String(cString: UnsafePointer(FridayValue!))
                
                
                MonDay.text = "   周一:\(Monday)"
                TuesDay.text = "   周二:\(Tuesday)"
                WednesDay.text = "   周三:\(Wednesday)"
                ThursDay.text = "   周四:\(Thursday)"
                FriDay.text = "   周五:\(Friday)"
                
            }
            sqlite3_finalize(statement)
            
        }
        
    }
    
    
    
    
    
    //获取Documents文档路径
    func getDocumentsDirectory() -> String {
        
        let documentDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
        
        return documentDir
    }
    
    
    
}
