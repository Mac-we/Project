import UIKit


class BianQianViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource{

    
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
    var dataArraytitle:[String] = []
   // var dataArraycontent:[String] = []
    var tableView01 = UITableView()
    var image = UIImageView()
    var btnItemDelete = UIButton()
    let refreshControl = UIRefreshControl()
    var collectionView: UICollectionView!
    
    
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        setNavigationBar()
        //链接数据库
        connectDatabase()
        //查询数据库
        selectData()
        setupUI()
    }

    
    override func viewWillAppear(_ animated: Bool) {
//        selectData()
//        //数据刷新
//        self.collectionView.reloadData()
//
    }
    
    //MARK:布局----------------------------------
    
    
    /// 设置UI
    func setupUI()
    {
        
      
        //image.alpha = 0.5
        image.image = UIImage(named: "便签背景")
        view.addSubview(image)
        image.snp.makeConstraints { (maker) in
            
            maker.top.equalToSuperview()
            
            maker.height.equalTo(SCREEN_HEIGHT)
            maker.width.equalTo(SCREEN_WIDTH)
        }
        
         //设置布局流格式
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: (SCREEN_WIDTH*0.425 ), height: (SCREEN_HEIGHT*0.1875) )
        layout.sectionInset = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
        layout.minimumLineSpacing = 20//列间距
        layout.minimumInteritemSpacing = 20//行间距
        collectionView = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collectionView.register(collectionViewCell.self, forCellWithReuseIdentifier: "collectionViewCell")
        //Collection View代理设置
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.refreshControl = refreshControl
        refreshControl.backgroundColor = UIColor.gray
        refreshControl.attributedTitle = NSAttributedString(string: "刷新一下：\(NSDate())", attributes: [NSAttributedString.Key.foregroundColor:UIColor.white])//设置文字颜色
        refreshControl.tintColor = UIColor.gray//小菊花的颜色
        refreshControl.tintAdjustmentMode = .dimmed //色彩调整模式
        refreshControl.addTarget(self, action: #selector(addcount), for: .valueChanged)
        //透明度
        collectionView.alpha = 0.8
        
        //设置垂直滚动是否滚到item的最底部
        collectionView.alwaysBounceVertical = true
        
        //设置uicollectionView的单元格点击
        collectionView.allowsSelection = true
        
        //开启uicollectionView的分页显示效果
        collectionView.isPagingEnabled = true
        
        collectionView.backgroundColor = UIColor(red: 242/255.0, green: 234/255.0, blue: 231/255.0, alpha: 0)
       //将Collection View添加到主视图中
        view.addSubview(collectionView)
        
    
        
        //添加拖动手势
        let gesture = UILongPressGestureRecognizer(target: self, action: #selector(viewCustom(_ :)))
        collectionView.addGestureRecognizer(gesture)
    }
    
    @objc func viewCustom(_ longPress:UILongPressGestureRecognizer){
        let point:CGPoint = longPress.location(in: longPress.view)
        let indexPath = self.collectionView?.indexPathForItem(at: point)
        if(longPress.state == .began &&  indexPath == nil){return;}
        switch longPress.state {
        case .began:
            self.collectionView?.beginInteractiveMovementForItem(at: indexPath!)
            break
        case .changed:
            self.collectionView?.updateInteractiveMovementTargetPosition(point)
            break
        case .ended:
            self.collectionView?.endInteractiveMovement()
            break
        default:
            self.collectionView?.cancelInteractiveMovement()
            break
        }
        
    }


    
    //    行数
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArraytitle.count
    }
    //    获取单元格
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionViewCell", for: indexPath) as! collectionViewCell
        //cell.imageView.image = UIImage(named:"\(dataSource[indexPath.row])");
        //cell.backgroundColor = .gray
        cell.titleLabel.text = dataArraytitle[indexPath.row]
        cell.titleLabel.textAlignment = .center
        cell.titleLabel.lineBreakMode = .byWordWrapping
        cell.titleLabel.numberOfLines = 0
        return cell
 
    }
    
  
    @objc func addcount(){
        selectData()
        self.collectionView.reloadData()
        self.refreshControl.endRefreshing()
        
    }
    
    
    
    //点击删除
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        dataArraytitle.remove(at: indexPath.row)
        collectionView.deleteItems(at: [indexPath])
     
    }
    
    //item 可以移动
    func collectionView(_ collectionView: UICollectionView, canMoveItemAt indexPath: IndexPath) -> Bool {
        return true;
    }
    //item 拖动结束时触发
    func collectionView(_ collectionView: UICollectionView, moveItemAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let sourceIndex = dataArraytitle[sourceIndexPath.row];
         dataArraytitle.remove(at: sourceIndexPath.row)
         dataArraytitle.insert(sourceIndex, at: destinationIndexPath.row)
        
    }
  
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    
    
    
    func setNavigationBar() {
        // 1, 创建导航栏右按钮
        let rightItem = UIBarButtonItem(title: "", style: .plain, target: self, action: #selector(rightItemOnclick(sender:)))
        navigationItem.rightBarButtonItem = rightItem
        rightItem.setBackgroundImage(UIImage(named: "添加标签"), for: .normal, barMetrics: .default)
        navigationController?.navigationBar.barTintColor = UIColor(red: 112/255.0, green: 200/255.0, blue: 240/255.0, alpha: 0)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.titleTextAttributes = [
            // 1, 设置字号大小
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20),
            // 2, 设置文本颜色
            NSAttributedString.Key.foregroundColor: UIColor.white,
        ]
    }
    
    @objc func rightItemOnclick(sender: UIBarButtonItem) {
        // 1, 获取设置控制器
        let BQController = storyboard?.instantiateViewController(withIdentifier: "BQController")
        BQController?.title = "添加便签"
        // 2, 将获取到的控制器推入导航栈(即跳转到新控制器)
        navigationController?.pushViewController(BQController!, animated: true)
    }
    
    

 // MARK:数据操作----------------------------------
  
    

    //打开数据库
    func connectDatabase(){
        let dataFilePath = URL(fileURLWithPath: getDocumentsDirectory()).appendingPathComponent("database.sqlite")
        if sqlite3_open(dataFilePath.absoluteString, &database) != SQLITE_OK {
            sqlite3_close(database)
            print("数据库无法打开")
        }
    }
    
    //查询数据库
    
    func selectData(){
        
        let sql = "SELECT * FROM NoteRecords "
        var statement:OpaquePointer? = nil
        if sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK {
            
            while sqlite3_step(statement) == SQLITE_ROW {
                
                let TitleValue = sqlite3_column_text(statement, 1)
                let Title = String(cString: UnsafePointer(TitleValue!))
               // let ContentValue = sqlite3_column_text(statement, 2)
              //  let Content = String(cString: UnsafePointer( ContentValue!))
                dataArraytitle.append(Title)
               // dataArraycontent.append(Content)
                

            }
            sqlite3_finalize(statement)
            
        }
    }
    

    
    
    //获取Documents文档路径
    func getDocumentsDirectory() -> String {
        
        let documentDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
        return documentDir
    }
    

    
    
}


// MARK:collectioViewCell----------------------
class collectionViewCell: UICollectionViewCell
{
    var titleLabel =  UILabel()
    var imageView = UIImageView()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        imageView.frame = CGRect(x: 0, y: 0, width: self.bounds.size.width, height: self.bounds.size.width)
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = UIColor(red: 219/255, green: 236/255, blue: 225/255, alpha: 1)
        imageView.layer.cornerRadius = 10
        //imageView.image = UIImage(named: "便签头图")
        titleLabel = UILabel(frame: CGRect(x: 0, y: imageView.frame.origin.y , width: self.bounds.size.width, height: self.bounds.size.height))
        //titleLabel.textAlignment = .center
       
       
        
        addSubview(imageView)
        addSubview(titleLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

