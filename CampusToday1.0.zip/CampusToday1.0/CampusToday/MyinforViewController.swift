import UIKit
import SnapKit

class MyinforViewController: UIViewController,UITableViewDelegate, UITableViewDataSource  {
    
    var tableView = UITableView()
    var BG = UIImageView()
    var img = UIImageView()
    var btn = UIButton()
    var lable1 = UILabel()
    var lable2 = UILabel()
    let imagePickerController = UIImagePickerController()
    let dataAerraypic = ["账号","个人资料","学校","消费记录","反馈"]
    let dataArray = ["6666666","男 22岁 摩羯座 北京","安徽信息工程学院","消费记录","帮助与反馈"]
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
    var dataArrayName:[String] = []
    var dataArrayAccount:[String] = []
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        connectDatabase()
        selectData()
       
    }
    
 //MARK:布局----------------------------------
    
    func layoutView(){
        
        
        let rightItem = UIBarButtonItem(title: "", style: .plain, target: self, action: #selector(rightItemOnclick(sender:)))
        navigationItem.rightBarButtonItem = rightItem
         rightItem.setBackgroundImage(UIImage(named: "退出登录"), for: .normal, barMetrics: .default)
        navigationController?.navigationBar.barTintColor = UIColor(red: 112/255.0, green: 200/255.0, blue: 240/255.0, alpha: 1.0)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.titleTextAttributes = [
            // 1, 设置字号大小
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 21),
            // 2, 设置文本颜色
            NSAttributedString.Key.foregroundColor: UIColor.white,
        ]
        
        
        BG.image = UIImage(named: "一人之下")
        view.addSubview(BG)
        BG.snp.makeConstraints { (maker) in
            maker.top.bottom.width.height.equalToSuperview()
            
        }

        
        img.image = UIImage(named: "头像")
        view.addSubview(img)
        img.snp.makeConstraints { (maker) in
            maker.height.width.equalTo(SCREEN_WIDTH*0.4 )
            maker.top.equalToSuperview().offset(SCREEN_HEIGHT*0.2)
            maker.centerX.equalToSuperview()
        }
        
        
        let lable2 = UILabel(frame: CGRect(x: 50, y: 400, width: 300, height: 50))
        view.addSubview(lable2)
        lable2.text = "Qw"
        lable2.font = UIFont.systemFont(ofSize: 23)
        lable2.textColor = .black
        lable2.textAlignment = .center
        lable2.snp.makeConstraints { (maker) in
            maker.top.equalTo(img).offset(SCREEN_WIDTH*0.5)
            maker.width.height.equalTo(lable2.snp.size)
            maker.centerX.equalToSuperview()
            
        }
        tableView.alpha = 0.5
        tableView.rowHeight = 80
        tableView.delegate = self
        tableView.dataSource = self
        view.addSubview(tableView)
        tableView.backgroundColor = UIColor(red: 79/255.0, green: 151/255.0, blue: 99/255.0, alpha: 0)
        tableView.snp.makeConstraints { (maker) in
            maker.top.equalTo(lable2).offset(SCREEN_WIDTH*0.1)
            maker.width.equalToSuperview()
            maker.height.equalTo(SCREEN_HEIGHT*0.4)
            maker.bottom.equalToSuperview()
            
        }
        
        
       
        
    }
    
    @objc func rightItemOnclick(sender: UIBarButtonItem) {
      
        //添加成功添加弹窗
        let AlertVC = UIAlertController(title: "提示", message: "确定退出吗?", preferredStyle: .alert)
        // let AlertVC = UIAlertController(title: "弹出提示", message: "这是个弹出框", preferredStyle: .actionSheet)
        
        let SureAction = UIAlertAction(title: "确定", style: .default) { (action) in
            print(action.title!)
            
            //跳转页面
            let LoginVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! ViewController
            LoginVC.modalPresentationStyle = .fullScreen
            self.present(LoginVC, animated: true) {
                print("跳转到登录页面...")
            }
        }
        
        let DenyAction = UIAlertAction(title: "取消", style: .cancel) { (action) in
            print(action.title!)
        }
        AlertVC.addAction(SureAction)
        AlertVC.addAction(DenyAction)
        self.present(AlertVC, animated: true, completion: nil)
        
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int)
        -> Int {
            return dataAerraypic.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)-> UITableViewCell {
            let identifier = "Cell"
            
            var cell = tableView.dequeueReusableCell(withIdentifier: identifier)
            
            if cell == nil {
                cell = UITableViewCell(style: .subtitle, reuseIdentifier: identifier)
            }
        
        
            cell?.textLabel?.text = dataArray[indexPath.row]
            cell?.detailTextLabel?.text = nil
            cell?.textLabel?.font = UIFont.systemFont(ofSize: 15, weight: .bold)
            cell?.accessoryType = .disclosureIndicator
            cell?.accessoryType = UITableViewCell.AccessoryType.disclosureIndicator
            let image = UIImage(named:"\(dataAerraypic[indexPath.row])")
            cell?.imageView?.image = image
            return cell!
    }
        
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // 1, 获取设置控制器
        let cellVC = storyboard?.instantiateViewController(withIdentifier: "cellVC")
        cellVC?.title = ""
        // 2, 将获取到的控制器推入导航栈(即跳转到新控制器)
        navigationController?.pushViewController(cellVC!, animated: true)
    }
    
    
    
//MARK:数据操作----------------------------------
    
  
    
    //打开数据库
    func connectDatabase(){
        let dataFilePath = URL(fileURLWithPath: getDocumentsDirectory()).appendingPathComponent("database.sqlite")
        if sqlite3_open(dataFilePath.absoluteString, &database) != SQLITE_OK {
            sqlite3_close(database)
            print("数据库无法打开")
        }
    }
    
    //查询数据库
    
    func selectData(){
        
        let sql = "SELECT * FROM USERS "
        var statement:OpaquePointer? = nil
        if sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK {
            
            while sqlite3_step(statement) == SQLITE_ROW {
                
                let NameValue = sqlite3_column_text(statement, 1)
                let Name = String(cString: UnsafePointer(NameValue!))
               
                let AccountValue = sqlite3_column_text(statement, 3)
                let Account = String(cString: UnsafePointer( AccountValue!))
                
                  print("\(Name)")
                  print("\(Account)")
                
              
                dataArrayName.append(Name)
                dataArrayAccount.append(Account)
                
            }
            sqlite3_finalize(statement)
            
        }
    }
    
    
    
    
    //获取Documents文档路径
    func getDocumentsDirectory() -> String {
        
        let documentDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
        print(documentDir)
        
        return documentDir
    }
    
    
    
    
    
    
    }
    
    

    

