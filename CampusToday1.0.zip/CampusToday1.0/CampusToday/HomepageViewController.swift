//
//  HomepageViewController.swift
//  Recipes
//
//  Created by HumbertCheung on 2020/10/14.
//  Copyright © 2020 HumbertCheung. All rights reserved.
//

import UIKit
import SnapKit
//第三方分页视图控件
import PagingMenuController

class HomepageViewController: UIViewController, UIScrollViewDelegate {
//MARK:声明----------------------------------
    let scrollView = UIScrollView() // 滚动视图
    let pageControl = UIPageControl() // 分页控制器
    var timer = Timer() // 定时器
    var btn = UIButton()
    var lab1 = UILabel()
    var lab2 = UILabel()
    var lab3 = UILabel()
    var MonDay = UILabel()
    var TuesDay = UILabel()
    var WednesDay = UILabel()
    var ThursDay = UILabel()
    var FriDay = UILabel()
    var btn1 = UIButton()
    var btn2 = UIButton()
    var btn3 = UIButton()
    var image = UIImageView()
    var database:OpaquePointer? = nil//定义数据库.类型为不透面膜指针
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        title = "主页"
        
       setNavigationBar() 
        
        
        layoutViews()
        // 设置当前控制器为scrollView的代理
        scrollView.delegate = self
        // 启动定时器
        setTimer()
        BuJu()
     
        
        //分页菜单配置
        let options = PagingMenuOptions()
        //分页菜单控制器初始化
        let pagingMenuController = PagingMenuController(options: options)
        //分页菜单控制器尺寸设置
        pagingMenuController.view.frame.origin.y += SCREEN_HEIGHT*0.60
        pagingMenuController.view.frame.size.height -= 100
        
        //建立父子关系
        addChild(pagingMenuController)
        //分页菜单控制器视图添加到当前视图中
        view.addSubview(pagingMenuController.view)
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    //MARK:布局----------------------------------
    
    
    //分页菜单配置
    private struct PagingMenuOptions: PagingMenuControllerCustomizable {
        //第1个子视图控制器
        private let firstViewController = FirstViewController()
        //第2个子视图控制器
        private let secondViewController = SecondViewController()
        //第3个子视图控制器
        private let thirdViewController = ThirdViewController()
        //第4个子视图控制器
        private let fourthViewController = FourthViewController()
        //第5个子视图控制器
        private let fifthViewController = FifthViewController()
        
        
        
        
        //组件类型
        fileprivate var componentType: ComponentType {
            return .all(menuOptions: MenuOptions(), pagingControllers: pagingControllers)
        }
        
        //所有子视图控制器
        fileprivate var pagingControllers: [UIViewController] {
            return [firstViewController, secondViewController, thirdViewController,fourthViewController,fifthViewController]
        }
        
        //菜单配置项
        fileprivate struct MenuOptions: MenuViewCustomizable {
            //菜单显示模式
            var displayMode: MenuDisplayMode {
                return .segmentedControl
            }
            //菜单项
            var itemsOptions: [MenuItemViewCustomizable] {
                return [MenuItem1(), MenuItem2() ,MenuItem3(),MenuItem4(),MenuItem5()]
            }
        }
        
        //第1个菜单项
        fileprivate struct MenuItem1: MenuItemViewCustomizable {
            //自定义菜单项名称
            var displayMode: MenuItemDisplayMode {
                return .text(title: MenuItemText(text: "第1周"))
            }
        }
        
        //第2个菜单项
        fileprivate struct MenuItem2: MenuItemViewCustomizable {
            //自定义菜单项名称
            var displayMode: MenuItemDisplayMode {
                return .text(title: MenuItemText(text: "第2周"))
            }
        }
    }
    //第3个菜单项
    fileprivate struct MenuItem3: MenuItemViewCustomizable {
        //自定义菜单项名称
        var displayMode: MenuItemDisplayMode {
            return .text(title: MenuItemText(text: "第3周"))
        }
    
    }
    
    //第3个菜单项
    fileprivate struct MenuItem4: MenuItemViewCustomizable {
        //自定义菜单项名称
        var displayMode: MenuItemDisplayMode {
            return .text(title: MenuItemText(text: "第4周"))
        }
        
    }
    
        
    //第3个菜单项
    fileprivate struct MenuItem5: MenuItemViewCustomizable {
        //自定义菜单项名称
        var displayMode: MenuItemDisplayMode {
            return .text(title: MenuItemText(text: "第5周"))
        }
        
    }
    
    
    func BuJu(){
        
     
        
        
        view.addSubview(lab1)
        lab1.textColor = .black
        lab1.text = "一键求助"
        lab1.backgroundColor = .white
        lab1.font = UIFont.systemFont(ofSize: 25,weight:.bold)
        lab1.textAlignment = .center
        lab1.snp.makeConstraints({ (maker) in
            maker.top.equalTo(scrollView.snp.bottom).offset(30)
            maker.width.equalTo(SCREEN_WIDTH*0.3)
            maker.left.equalToSuperview().offset(SCREEN_WIDTH*0.05)
            maker.right.equalToSuperview().offset(-SCREEN_WIDTH*0.65)
        })
        
        
        
        btn1.setBackgroundImage(UIImage(named: "医护求助"), for: .normal)
        view.addSubview(btn1)
        btn1.snp.makeConstraints { (maker) in
            maker.left.equalToSuperview().offset(SCREEN_WIDTH*0.05)
            maker.top.equalTo(lab1).offset(SCREEN_HEIGHT*0.05)
            maker.width.equalTo(SCREEN_WIDTH*0.26)
            maker.right.equalToSuperview().offset(-SCREEN_WIDTH*0.67)
        }
        btn1.addTarget(self, action: #selector(Help1(sender:)), for: .touchUpInside)
        
        
        btn2.setBackgroundImage(UIImage(named: "消防求助"), for: .normal)
        view.addSubview(btn2)
        btn2.snp.makeConstraints { (maker) in
            maker.left.equalTo(btn2).offset(SCREEN_WIDTH*0.05)
            maker.top.equalTo(lab1).offset(SCREEN_HEIGHT*0.05)
            maker.width.equalTo(SCREEN_WIDTH*0.26)
            maker.right.equalToSuperview().offset(-SCREEN_WIDTH*0.36)
        }
         btn2.addTarget(self, action: #selector(Help2(sender:)), for: .touchUpInside)
        
        btn3.setBackgroundImage(UIImage(named: "安全求助"), for: .normal)
        view.addSubview(btn3)
        btn3.snp.makeConstraints { (maker) in
            maker.left.equalTo(btn3).offset(-SCREEN_WIDTH*0.05)
            maker.top.equalTo(lab1).offset(SCREEN_HEIGHT*0.05)
            maker.width.equalTo(SCREEN_WIDTH*0.26)
            maker.right.equalToSuperview().offset(-SCREEN_WIDTH*0.05)
        }
         btn3.addTarget(self, action: #selector(Help3(sender:)), for: .touchUpInside)
        
        
        
        view.addSubview(lab2)
        lab2.textColor = .black
        lab2.text = "今日课程"
        lab2.backgroundColor = .white
        lab2.font = UIFont.systemFont(ofSize: 25,weight:.bold)
        lab2.textAlignment = .center
        lab2.snp.makeConstraints({ (maker) in
            maker.top.equalTo(btn1).offset(SCREEN_HEIGHT*0.14)
            maker.left.equalToSuperview().offset(SCREEN_WIDTH*0.05)
            maker.width.equalTo(SCREEN_WIDTH*0.3)
        })
        
        
        
        let date = NSDate()
        let dateFormatter = DateFormatter()
        //日期显示格式，可按自己需求显示
        dateFormatter.dateFormat = "yyy-MM-dd-eeee"
        let strNowTime = dateFormatter.string(from: date as Date) as String
        lab3.text = strNowTime
        lab3.textColor = .black
        lab3.font = UIFont.systemFont(ofSize: 19)
        view.addSubview(lab3)
        lab3.snp.makeConstraints { (maker) in
             maker.top.equalTo(btn1).offset(SCREEN_HEIGHT*0.14)
            maker.left.equalTo(lab2.snp.right).offset(SCREEN_HEIGHT*0.05)
            maker.width.equalTo(SCREEN_WIDTH*0.5)
        }

        
        
    }
    
    @objc func Help1(sender: UIButton ){
         //打电话120
        UIApplication .shared.openURL( NSURL (string : "tel://120" )! as URL)
     
    }
    
    
    @objc func Help2(sender: UIButton ){
         //打电话119
        UIApplication .shared.openURL( NSURL (string : "tel://119" )! as URL)
        
    }
    
    @objc func Help3(sender: UIButton ){
         //打电话110
        UIApplication .shared.openURL( NSURL (string : "tel://110" )! as URL)
        
    }
    
    
    
    
    
    
    
    
    
    func setNavigationBar() {
        // 1, 创建导航栏右按钮
        let rightItem = UIBarButtonItem(title: "", style: .plain, target: self, action: #selector(rightItemOnclick(sender:)))
        navigationItem.rightBarButtonItem = rightItem
        rightItem.setBackgroundImage(UIImage(named: "我的大学"), for: .normal, barMetrics: .default)
        navigationController?.navigationBar.barTintColor = UIColor(red: 112/255.0, green: 200/255.0, blue: 240/255.0, alpha: 1.0)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.titleTextAttributes = [
            // 1, 设置字号大小
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 21),
            // 2, 设置文本颜色
            NSAttributedString.Key.foregroundColor: UIColor.white,
        ]
    }
    
    @objc func rightItemOnclick(sender: UIBarButtonItem) {
        // 1, 获取设置控制器
        let MyuniversityVC = storyboard?.instantiateViewController(withIdentifier: "MyuniversityVC")
       MyuniversityVC?.title = "我的大学"
        // 2, 将获取到的控制器推入导航栈(即跳转到新控制器)
        navigationController?.pushViewController(MyuniversityVC!, animated: true)
    }
    
    func layoutViews(){
        // 1, 设置srollView
        view.addSubview(scrollView)
        scrollView.backgroundColor = UIColor(red: 79/255.0, green: 151/255.0, blue: 99/255.0, alpha: 1.0)
        scrollView.snp.makeConstraints { (maker) in
            maker.top.equalToSuperview().inset(UIApplication.shared.statusBarFrame.height + 44)
            maker.left.width.equalToSuperview()
            maker.height.equalTo(200) // 高度是根据图片宽高比例计算出的
        }
        // 2, 设置scrollView滚动的内容尺寸,宽度为4个屏幕宽度,高度为0即垂直方向不滚动
        scrollView.contentSize = CGSize(width: SCREEN_WIDTH * 4, height: 0)
        // 设置scrollView可分页
        scrollView.isPagingEnabled = true
        
        // 3, 创建用来滚动的内容,内容为4个用来展示广告的iamgeView
        for i in 0..<4 {
            let btn = UIButton(frame: CGRect(x: CGFloat(i) * SCREEN_WIDTH, y: 0, width: SCREEN_WIDTH, height: 200))
            btn.setBackgroundImage(UIImage(named: "banner\(i+1)"), for: .normal)
            scrollView.addSubview(btn)
            btn.addTarget(self, action: #selector(DianJiGunDong(sender:)), for: .touchUpInside)
        }
        
        // 设置分页控制器
        view.addSubview(pageControl)
        pageControl.numberOfPages = 4 // 总页数
        pageControl.currentPage = 0 // 当前页
        pageControl.currentPageIndicatorTintColor = .white// 设置当前页圆点颜色
        pageControl.pageIndicatorTintColor = .white // 设置其他页圆点颜色
        pageControl.snp.makeConstraints { (maker) in
            maker.left.bottom.equalTo(scrollView)
            maker.height.equalTo(20)
            maker.width.equalToSuperview()
        }
        // 为分页控制器添绑定事件。此时事件类型是：valueChanged 。即当前页的索引值发生变化时触发改事件
        pageControl.addTarget(self, action: #selector(pageControlOperation(pageControl:)), for: .valueChanged)
        
 
  
    }
    
 
    @objc func DianJiGunDong(sender: UIButton){
        let AlertVC = UIAlertController(title: "提示", message: "功能暂未实现,尽情期待", preferredStyle: .alert)
        // let AlertVC = UIAlertController(title: "弹出提示", message: "这是个弹出框", preferredStyle: .actionSheet)
        
        let SureAction = UIAlertAction(title: "确定", style: .default) { (action) in
            print(action.title!)
        }
        
        let DenyAction = UIAlertAction(title: "取消", style: .destructive) { (action) in
            print(action.title!)
        }
        
        AlertVC.addAction(SureAction)
        AlertVC.addAction(DenyAction)
        self.present(AlertVC, animated: true, completion: nil)
 
    }
    
    
    // 分页控制器绑定方法
    @objc func pageControlOperation(pageControl: UIPageControl) {
        
        // 当进行分页时,按照当前页来设置偏移量
        scrollView.setContentOffset(CGPoint(x: CGFloat(pageControl.currentPage) * SCREEN_WIDTH, y: 0), animated: true)
    }
    
    // 设置定时器
    func setTimer() {
        // 设置定时器
        timer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true, block: { (t) in
            if self.pageControl.currentPage == 3 {
                self.pageControl.currentPage = 0
            } else {
                self.pageControl.currentPage += 1
            }
            // 在pageControl的value发生变化时, 手动触发对应的方法
            self.pageControlOperation(pageControl: self.pageControl)
        })
    }
    
    // 代理方法，当视图被滚动时会调用此方法
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let x = scrollView.contentOffset.x
        if x >= SCREEN_WIDTH * 3.3 {
            scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        }
        // 根据滚动视图水平方向上的偏移量来计算当前页
        pageControl.currentPage = Int(CGFloat(x) / SCREEN_WIDTH)
    }
    
    // 代理方法, 当滚动视图开始拖拽时停止定时器
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        timer.invalidate()
    }
    
    // 代理方法, 当滚动视图停止拖拽时再启动定时器
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        setTimer()
    }
    
    
  
    
    
}
    
    



